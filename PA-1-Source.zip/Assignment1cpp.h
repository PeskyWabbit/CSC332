#pragma 

int main();

int calculateGcd(int num1, int num2);

int euclids1(int a, int b);

int euclids2(int a, int b);